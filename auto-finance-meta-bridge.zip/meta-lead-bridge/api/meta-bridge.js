import { createHandler } from '../lib/bridge.js';
export const config = { api: { bodyParser: false } };
export default createHandler();
