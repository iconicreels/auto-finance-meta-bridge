# Send this bridge to Vercel

1. Unzip auto-finance-meta-bridge.zip.
2. Create a private GitHub repository for the bridge. Upload the contents of the meta-lead-bridge folder so package.json, vercel.json, api, and lib are at the repository root. Do not upload the ZIP itself.
3. In Vercel, choose Add New → Project and import that repository. Select the fbigtt-leads team and Framework Preset Other. Leave Build Command and Output Directory unset.
4. Add the server-side environment variables listed below, then deploy. If you add them after deployment, redeploy.
5. Ensure the bridge's production callback is publicly reachable without a Vercel login. Only change protection on the bridge project.
6. In Meta Developers, use https://YOUR-VERCEL-DOMAIN/api/meta-bridge as the Page webhook callback. Enter the same META_VERIFY_TOKEN, subscribe to leadgen, and subscribe your Page to the app.
7. Create a Meta test lead and confirm it reaches the receiver or encrypted runtime logs.

## Required settings

- META_VERIFY_TOKEN: create a long random secret.
- META_APP_SECRET: the secret for your Meta app.
- META_PAGE_ACCESS_TOKEN: a fresh Page access token with lead retrieval access.
- META_GRAPH_VERSION: the Graph version supported by your app; the existing project used v26.0. Confirm it in Meta.
- META_ALLOWED_PAGE_IDS: your Facebook Page ID (recommended).

Choose one independent destination:

- Forwarding: set BRIDGE_FORWARD_URL to your private HTTPS receiver and BRIDGE_FORWARD_TOKEN to its bearer credential. The receiver must save each lead before returning success and deduplicate by Idempotency-Key.
- Temporary encrypted logging: set BRIDGE_LOG_ENCRYPTION_KEY to a random 32-byte key represented as 64 hex characters. Save the key securely. Logs expire and are not a permanent lead database.

Enter secrets directly into Vercel, never GitHub or chat. No CRM connection is required. The bridge rejects unsigned POSTs and retrieves full lead details on the server.

## Existing deployment

A separate copy already exists at https://auto-finance-meta-bridge.vercel.app/api/meta-bridge. Its public access is enabled, but Meta credentials and a lead destination have not been configured. You can finish configuring that project instead of creating another copy.

For code tests, run npm test with Node 22 or later. See README.md for retry behavior and operational limits.
