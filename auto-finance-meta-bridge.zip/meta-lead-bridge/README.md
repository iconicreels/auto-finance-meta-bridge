# Standalone Auto Finance Meta Lead Ads bridge

No CRM, database, SMTP, or frontend dependencies. The production finance site is unchanged. This package can deploy as a separate Vercel project, or its api/meta-bridge.js and lib/bridge.js can be added to a compatible Node ESM project after checking routing. Do not replace the existing CRM webhook or vercel.json.

## Environment variables

Set these as server-side secrets in Vercel Production (and Preview for testing), then redeploy:

| Variable | Purpose |
| --- | --- |
| META_VERIFY_TOKEN | A new random secret; enter the exact same value in Meta callback verification. |
| META_APP_SECRET | Required app secret for signed POST validation; for existing app 1458977796081211, confirm ownership first. |
| META_PAGE_ACCESS_TOKEN | Fresh Page token authorized to retrieve leads for Fbigtt Auto. META_ACCESS_TOKEN is also supported as a fallback. |
| META_GRAPH_VERSION | Required explicit version supported by your Meta app; v26.0 matches the inspected existing repo. Confirm in Meta before activation. |
| META_ALLOWED_PAGE_IDS | Recommended comma-separated Page IDs allowed to deliver leads. |
| BRIDGE_FORWARD_URL | Optional private HTTPS receiver; receives the complete lead as JSON. |
| BRIDGE_FORWARD_TOKEN | Required bearer credential when forwarding. |
| BRIDGE_LOG_ENCRYPTION_KEY | Required when not forwarding: random 32-byte key encoded as 64 hex characters. Save it securely outside Vercel logs. |

Use newly issued secrets rather than credentials visible in the earlier chat. No secret belongs in source control or public frontend variables.

## Callback and activation

For a separate project named auto-finance-meta-bridge, use https://auto-finance-meta-bridge.vercel.app/api/meta-bridge only after that production domain is confirmed. For an installation into the original project, the proposed callback is https://vehicle-financing.vercel.app/api/meta-bridge; that project was not found in the connected Vercel account, so this URL is not yet deployed.

In Meta Developers, configure the Page object webhook with the confirmed callback URL and META_VERIFY_TOKEN, subscribe to leadgen, and subscribe the correct Page to the app. Ensure the token has leads_retrieval and the required Page subscription permissions, and the app/user has lead access for this Page in Meta Business settings. Production access and App Review requirements must be checked for your app. The prior chat's missing-permissions error is not resolved by code alone.

The callback must be publicly reachable: Vercel SSO/password protection must not intercept Meta GET or POST requests. Adjust protection only for the separate bridge project or use an appropriately scoped public custom domain; do not disable protection for the CRM.

## Destination behavior and limitations

Forwarding sends notification metadata and the retrieved raw lead with an Idempotency-Key of meta-lead-<lead ID>. The receiver must durably store the lead before returning 2xx and enforce uniqueness on that key. Redirects are rejected so credentials cannot follow redirects. Forwarding takes precedence over logging.

Without forwarding, the complete record is AES-256-GCM encrypted before it enters Vercel runtime logs. No names, emails, phone numbers, access tokens, or raw provider errors are printed. Export logs within your plan's retention window. Logs are temporary operational storage, not a permanent lead database, and may be truncated or lost; configure a durable receiver or log drain before relying on this for live campaigns. Duplicate deliveries across requests are possible; encrypted logs must be deduplicated after decryption by record.lead_id. Decrypt using the saved hex key, base64 iv and tag, and base64 ciphertext. Never expose a public lead listing endpoint.

200 is returned only after every lead is forwarded/logged. Retrieval and destination failures return 502 to allow Meta retries. Events are deduplicated inside a request. Partial batches may repeat already processed leads on retry. Requests are bounded to 1 MB and processing to 45 seconds plus runtime overhead; high volume should use a durable queue before acknowledgement.

## Test and deploy

Run npm test with Node 22 or later (no dependencies). Tests use fake tokens and synthetic leads; they do not contact Meta or send real customer data. Deploy this directory as a separate Vercel project with framework Other; no build/install dependencies are required.

After deploying, verify the GET callback returns the exact hub.challenge with the correct token and 403 with a wrong token. Unsigned POST must return 401. Send a Meta test lead using the Lead Ads Testing Tool and confirm decrypted log content or durable receiver storage. A signed mock notification cannot prove Meta token permissions. Monitor 502s and token expiry; reconcile leads with Meta if deliveries stop.

## Inspection evidence

Connected GitHub repository fbigttleads/fbigtt-auto-finance-crm-v7grok (main bf118953dd3909cba978d1d3ad3bd1c60f94a242) has an existing api/meta-webhook.js which imports CRM database helpers and inserts into crm_leads and crm_lead_history. Its existing routing builds api/*.js and its environment template uses META_GRAPH_VERSION=v26.0. Connected Vercel lists v7 and v8 projects, but vehicle-financing lookup returns project-not-found. A separate deployment avoids making assumptions about that site's ownership or routing.

Official protocol references: https://developers.facebook.com/docs/graph-api/webhooks/getting-started/ and https://developers.facebook.com/docs/marketing-api/guides/lead-ads/retrieving/ . Meta documentation returned rate limiting during this session; verify the app's version and permissions in its dashboard. Official sample: https://github.com/fbsamples/lead-ads-webhook-sample .
