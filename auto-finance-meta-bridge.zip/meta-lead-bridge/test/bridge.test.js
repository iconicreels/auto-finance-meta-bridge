import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Readable } from 'node:stream';
import { createHmac, createDecipheriv } from 'node:crypto';
import { createHandler } from '../lib/bridge.js';
const env = { META_VERIFY_TOKEN: 'verify-test', META_APP_SECRET: 'secret-test', META_PAGE_ACCESS_TOKEN: 'page-test', META_GRAPH_VERSION: 'v26.0', BRIDGE_LOG_ENCRYPTION_KEY: 'ab'.repeat(32) };
const body = JSON.stringify({ object: 'page', entry: [{ id: '123', changes: [{ field: 'leadgen', value: { leadgen_id: '456' } }] }] });
async function run({ method = 'POST', url = '/', raw = body, signature = true, settings = env, fetcher } = {}) {
  const logs = [];
  const req = Readable.from([Buffer.from(raw)]);
  Object.assign(req, { method, url, headers: { 'x-hub-signature-256': signature ? 'sha256=' + createHmac('sha256', env.META_APP_SECRET).update(raw).digest('hex') : 'sha256=bad' } });
  const res = { setHeader() {}, status(s) { this.code = s; return this; }, send(s) { this.body = s; return this; } };
  let calls = 0;
  await createHandler({ env: settings, logger: { info(s) { logs.push(s); }, error(s) { logs.push(s); } }, fetcher: async (...args) => { calls++; return fetcher ? fetcher(...args) : { ok: true, json: async () => ({ id: '456', field_data: [{ name: 'email', values: ['test@example.invalid'] }] }) }; } })(req, res);
  return { ...res, logs, calls };
}
test('verification succeeds with exact challenge; wrong and missing tokens fail', async () => {
  assert.equal((await run({ method: 'GET', url: '/?hub.mode=subscribe&hub.verify_token=verify-test&hub.challenge=12345' })).body, '12345');
  assert.equal((await run({ method: 'GET' })).code, 403);
  assert.equal((await run({ method: 'GET', settings: {} })).code, 503);
});
test('invalid signature fails before retrieving a lead', async () => {
  const r = await run({ signature: false }); assert.equal(r.code, 401); assert.equal(r.calls, 0);
});
test('signed lead is retrieved and logged as recoverable ciphertext', async () => {
  const r = await run(); assert.equal(r.code, 200); assert.equal(r.calls, 1);
  assert.ok(!r.logs.join('').includes('test@example.invalid'));
  const entry = JSON.parse(r.logs[0]);
  const cipher = createDecipheriv('aes-256-gcm', Buffer.from(env.BRIDGE_LOG_ENCRYPTION_KEY, 'hex'), Buffer.from(entry.iv, 'base64'));
  cipher.setAuthTag(Buffer.from(entry.tag, 'base64'));
  const record = JSON.parse(Buffer.concat([cipher.update(Buffer.from(entry.ciphertext, 'base64')), cipher.final()]));
  assert.equal(record.lead.field_data[0].values[0], 'test@example.invalid');
});
test('forwarding sends full lead with stable idempotency key and server-side tokens', async () => {
  let forwarded;
  const r = await run({ settings: { ...env, BRIDGE_FORWARD_URL: 'https://receiver.example.invalid/leads', BRIDGE_FORWARD_TOKEN: 'forward-test' }, fetcher: async (url, options) => {
    if (options.method === 'POST') { forwarded = options; return { ok: true }; }
    assert.equal(options.headers.Authorization, 'Bearer page-test'); assert.ok(!url.href.includes('page-test'));
    return { ok: true, json: async () => ({ id: '456', field_data: [] }) };
  } });
  assert.equal(r.code, 200); assert.equal(forwarded.headers['Idempotency-Key'], 'meta-lead-456'); assert.equal(r.logs.length, 0);
});
test('retrieval/forwarding failures are not acknowledged and do not leak provider errors', async () => {
  const r = await run({ fetcher: async () => { throw new Error('sensitive-token'); } }); assert.equal(r.code, 502); assert.ok(!JSON.stringify(r).includes('sensitive-token'));
  assert.equal((await run({ settings: { ...env, BRIDGE_FORWARD_URL: 'https://receiver.example.invalid', BRIDGE_FORWARD_TOKEN: 'token' }, fetcher: async (u, o) => o.method === 'POST' ? { ok: false } : { ok: true, json: async () => ({ id: '456', field_data: [] }) } })).code, 502);
});
test('bad JSON, oversized payload, unauthorized page, and missing destination fail', async () => {
  assert.equal((await run({ raw: '{' })).code, 400);
  assert.equal((await run({ raw: 'x'.repeat(1_000_001) })).code, 413);
  assert.equal((await run({ settings: { ...env, META_ALLOWED_PAGE_IDS: '999' } })).code, 403);
  assert.equal((await run({ settings: { ...env, BRIDGE_LOG_ENCRYPTION_KEY: '' } })).code, 503);
});
